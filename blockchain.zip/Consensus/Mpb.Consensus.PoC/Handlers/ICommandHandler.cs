﻿namespace Mpb.Consensus.PoC.Handlers
{
    internal interface ICommandHandler
    {
        internal void HandleCommand();
    }
}